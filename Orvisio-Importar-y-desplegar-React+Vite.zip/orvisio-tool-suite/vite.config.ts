import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0'
  },
  optimizeDeps: {
    exclude: ['bippy', "bippy/dist/jsx-runtime", "bippy/dist/jsx-dev-runtime"]
  },
  ssr: {
    noExternal: ['bippy']
  }
});