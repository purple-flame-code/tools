import React from 'react';

const LandingPage = () => {
  // SVG Icons exactos de Deal.ai pero en colores Orvisio
  const createIcon = (pathData: string) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d={pathData} fill="white"/>
    </svg>
  );

  const icons = {
    // AI Content Creation Icons
    aiPodcasts: createIcon("M12 3C7.58 3 4 6.58 4 11C4 15.42 7.58 19 12 19C16.42 19 20 15.42 20 11C20 6.58 16.42 3 12 3ZM13 17H11V7H13V17ZM15 15H17V9H15V15ZM7 15H9V9H7V15Z"),
    aiMovies: createIcon("M8 5V19L19 12L8 5Z"),
    aiSpokesperson: createIcon("M12 2C13.1 2 14 2.9 14 4V10C14 11.1 13.1 12 12 12C10.9 12 10 11.1 10 10V4C10 2.9 10.9 2 12 2ZM19 10V12C19 15.87 15.87 19 12 19C8.13 19 5 15.87 5 12V10H7V12C7 14.76 9.24 17 12 17C14.76 17 17 14.76 17 12V10H19ZM11 20H13V22H11V20Z"),
    audiobookMaker: createIcon("M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM9 17H7V7H9V17ZM13 17H11V7H13V17ZM17 17H15V7H17V17Z"),
    musicGenerator: createIcon("M12 3V12.26C11.5 12.09 11 12 10.5 12C8.57 12 7 13.57 7 15.5S8.57 19 10.5 19S14 17.43 14 15.5V7H18V5H12V3Z"),
    voiceOver: createIcon("M3 9V15H7L12 20V4L7 9H3ZM16.5 12C16.5 10.23 15.5 8.71 14 7.97V16.02C15.5 15.29 16.5 13.77 16.5 12ZM14 3.23V5.29C16.89 6.15 19 8.83 19 12C19 15.17 16.89 17.85 14 18.71V20.77C18.01 19.86 21 16.28 21 12C21 7.72 18.01 4.14 14 3.23Z"),

    // Marketing & Sales Icons
    vibeMarketer: createIcon("M16 6L18.29 8.29L13.41 13.17L9.41 9.17L2 16.59L3.41 18L9.41 12L13.41 16L19.71 9.71L22 12V6H16Z"),
    magicHooks: createIcon("M16 8L18.5 5.5L17.08 4.08L15 6.16L12.92 4.08L11.5 5.5L14 8H9C7.9 8 7 8.9 7 10V14C7 15.1 7.9 16 9 16H11V14H9V10H14L11.5 12.5L12.92 13.92L15 11.84L17.08 13.92L18.5 12.5L16 10H21C22.1 10 23 9.1 23 8C23 6.9 22.1 6 21 6H16V8Z"),
    scrollStoppingAds: createIcon("M19 3H5C3.89 3 3 3.89 3 5V19C3 20.11 3.89 21 5 21H19C20.11 21 21 20.11 21 19V5C21 3.89 20.11 3 19 3ZM12 17.5L6.5 12H10V8H14V12H17.5L12 17.5Z"),
    emailMarketing: createIcon("M20 4H4C2.9 4 2.01 4.9 2.01 6L2 18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4ZM20 8L12 13L4 8V6L12 11L20 6V8Z"),
    aeoFunnels: createIcon("M12 2L2 7L12 12L22 7L12 2ZM2 17L12 22L22 17L12 12L2 17Z"),
    leadGeneration: createIcon("M12 2C6.48 2 2 6.48 2 12S6.48 22 12 22S22 17.52 22 12S17.52 2 12 2ZM13 17H11V15H13V17ZM13 13H11V7H13V13Z"),

    // Business Intelligence Icons
    deepResearch: createIcon("M15.5 14H14.71L14.43 13.73C15.41 12.59 16 11.11 16 9.5C16 5.91 13.09 3 9.5 3S3 5.91 3 9.5S5.91 16 9.5 16C11.11 16 12.59 15.41 13.73 14.43L14 14.71V15.5L19 20.49L20.49 19L15.5 14ZM9.5 14C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5S14 7.01 14 9.5S11.99 14 9.5 14Z"),
    analyticsDashboard: createIcon("M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM9 17H7V10H9V17ZM13 17H11V7H13V17ZM17 17H15V13H17V17Z"),
    competitorAnalysis: createIcon("M12 2L13.09 8.26L20 9L13.09 9.74L12 16L10.91 9.74L4 9L10.91 8.26L12 2ZM4 16L5 19L8 20L5 21L4 24L3 21L0 20L3 19L4 16ZM20 16L21 19L24 20L21 21L20 24L19 21L16 20L19 19L20 16Z"),
    marketIntelligence: createIcon("M12 2C6.48 2 2 6.48 2 12S6.48 22 12 22S22 17.52 22 12S17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12S7.59 4 12 4S20 7.59 20 12S16.41 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z"),
    performanceOptimizer: createIcon("M12 15.5A3.5 3.5 0 0 1 8.5 12A3.5 3.5 0 0 1 12 8.5A3.5 3.5 0 0 1 15.5 12A3.5 3.5 0 0 1 12 15.5M19.43 12.98C19.47 12.66 19.5 12.33 19.5 12C19.5 11.67 19.47 11.34 19.43 11.02L21.54 9.37C21.73 9.22 21.78 8.95 21.66 8.73L19.66 5.27C19.54 5.05 19.27 4.97 19.05 5.05L16.56 6.05C16.04 5.65 15.48 5.32 14.87 5.07L14.49 2.42C14.46 2.18 14.25 2 14 2H10C9.75 2 9.54 2.18 9.51 2.42L9.13 5.07C8.52 5.32 7.96 5.66 7.44 6.05L4.95 5.05C4.73 4.96 4.46 5.05 4.34 5.27L2.34 8.73C2.21 8.95 2.27 9.22 2.46 9.37L4.57 11.02C4.53 11.34 4.5 11.67 4.5 12C4.5 12.33 4.53 12.65 4.57 12.97L2.46 14.63C2.27 14.78 2.21 15.05 2.34 15.27L4.34 18.73C4.46 18.95 4.73 19.03 4.95 18.95L7.44 17.94C7.96 18.34 8.52 18.68 9.13 18.93L9.51 21.58C9.54 21.82 9.75 22 10 22H14C14.25 22 14.46 21.82 14.49 21.58L14.87 18.93C15.48 18.68 16.04 18.34 16.56 17.94L19.05 18.95C19.27 19.04 19.54 18.95 19.66 18.73L21.66 15.27C21.78 15.05 21.73 14.78 21.54 14.63L19.43 12.98Z"),
    predictiveAnalytics: createIcon("M12 2L2 7L12 12L22 7L12 2ZM2 17L12 22L22 17V12L12 17L2 12V17Z"),

    // Design & Creative Icons
    imageEditor: createIcon("M9 2L7.17 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4H16.83L15 2H9ZM12 17C9.24 17 7 14.76 7 12S9.24 7 12 7S17 9.24 17 12S14.76 17 12 17ZM12 9C10.34 9 9 10.34 9 12S10.34 15 12 15S15 13.66 15 12S13.66 9 12 9Z"),
    logoMaker: createIcon("M12 2L3 7V17L12 22L21 17V7L12 2ZM12 4.14L18.25 7.5L12 10.86L5.75 7.5L12 4.14ZM5 9.13L11 12.13V19.26L5 16.26V9.13ZM19 16.26L13 19.26V12.13L19 9.13V16.26Z"),
    precisionImage: createIcon("M21 19V5C21 3.9 20.1 3 19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19ZM8.5 13.5L11 16.51L14.5 12L19 18H5L8.5 13.5Z"),
    brandKit: createIcon("M12 2L2 7L12 12L22 7L12 2ZM2 17L12 22L22 17V12L12 17L2 12V17Z"),
    socialTemplates: createIcon("M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM5 17L8.5 12.5L11 15.51L14.5 11L19 17H5Z"),
    creativeStudio: createIcon("M12 3C7.58 3 4 6.58 4 11C4 15.42 7.58 19 12 19C16.42 19 20 15.42 20 11C20 6.58 16.42 3 12 3ZM15.5 8L11 12.5L8.5 10L7 11.5L11 15.5L17 9.5L15.5 8Z")
  };

  const toolCategories = [
    {
      title: "AI Content Creation",
      tools: [
        {
          name: "AI Podcasts",
          description: "No mic, no editing, no recording—just instant audio from your content. Generate high-quality podcast episodes using one or two AI voices that sound like real hosts.",
          icon: icons.aiPodcasts
        },
        {
          name: "AI Movies",
          description: "Collaborate with AI to create amazing movies. AI Movies is your creative partner, bringing your stories to life with stunning visuals.",
          icon: icons.aiMovies
        },
        {
          name: "AI Spokesperson",
          description: "Create stunning UGC videos in minutes—no camera, no crew, no stress. Just write or generate a script, design your avatar, pick a voice.",
          icon: icons.aiSpokesperson
        },
        {
          name: "Audiobook Maker",
          description: "Transform your words into captivating audiobooks! Effortlessly convert any text into immersive audio experiences with lifelike voices.",
          icon: icons.audiobookMaker
        },
        {
          name: "AI Music Generator",
          description: "Got a vibe in your head? Let's make it real. Choose a style, enter a prompt, and AI Music Generator delivers a track that hits the exact mood.",
          icon: icons.musicGenerator
        },
        {
          name: "AI Voice Over",
          description: "Create stunning voiceovers effortlessly. Simply provide a URL or business description, choose a theme, and generate captivating audio content.",
          icon: icons.voiceOver
        }
      ]
    },
    {
      title: "Marketing & Sales",
      tools: [
        {
          name: "Vibe Marketer",
          description: "The easiest and fastest way to market your product with zero marketing skills required. AI-powered marketing campaigns made simple.",
          icon: icons.vibeMarketer
        },
        {
          name: "Magic Hooks",
          description: "Engage your audience from the first line with AI-generated hooks that promise high conversion rates. Tailored to your brand voice.",
          icon: icons.magicHooks
        },
        {
          name: "Scroll-Stopping Ads",
          description: "Capture your audience's attention with AI-crafted ads designed to stop them in their tracks. Leverage cutting-edge algorithms.",
          icon: icons.scrollStoppingAds
        },
        {
          name: "Email Marketing",
          description: "Revolutionize your email campaigns with AI-powered personalization and optimization. Create compelling, targeted messages.",
          icon: icons.emailMarketing
        },
        {
          name: "AEO Funnels",
          description: "Create high-converting sales funnels effortlessly with our AI-powered editor. Automated optimization suggestions included.",
          icon: icons.aeoFunnels
        },
        {
          name: "Lead Generation",
          description: "AI-powered lead generation system that identifies, qualifies, and nurtures prospects automatically. Smart targeting included.",
          icon: icons.leadGeneration
        }
      ]
    },
    {
      title: "Business Intelligence",
      tools: [
        {
          name: "Deep Research",
          description: "An AI-powered research assistant that streamlines deep research, summarizes complex topics, and uncovers key insights.",
          icon: icons.deepResearch
        },
        {
          name: "Analytics Dashboard",
          description: "Real-time business analytics with AI-powered insights. Track performance, identify trends, and make data-driven decisions.",
          icon: icons.analyticsDashboard
        },
        {
          name: "Competitor Analysis",
          description: "Monitor your competition with AI-powered analysis. Track pricing, features, marketing strategies, and market positioning.",
          icon: icons.competitorAnalysis
        },
        {
          name: "Market Intelligence",
          description: "Stay ahead with AI-driven market research. Identify opportunities, analyze trends, and understand customer behavior.",
          icon: icons.marketIntelligence
        },
        {
          name: "Performance Optimizer",
          description: "AI-powered optimization suggestions for your business processes. Improve efficiency and reduce operational costs.",
          icon: icons.performanceOptimizer
        },
        {
          name: "Predictive Analytics",
          description: "Forecast business outcomes with AI-powered predictive models. Anticipate trends and make proactive decisions.",
          icon: icons.predictiveAnalytics
        }
      ]
    },
    {
      title: "Design & Creative",
      tools: [
        {
          name: "AI Image Editor",
          description: "Unleash your creativity with an AI-powered image editor designed for marketers. Quickly edit and enhance images.",
          icon: icons.imageEditor
        },
        {
          name: "Logo Maker",
          description: "Design a unique and memorable logo that perfectly represents your brand with the help of AI. Professional-quality logos in minutes.",
          icon: icons.logoMaker
        },
        {
          name: "Precision Image Model",
          description: "Generate personalized AI images by creating a unique model from uploaded photos. Get tailored, high-quality visuals.",
          icon: icons.precisionImage
        },
        {
          name: "Brand Kit Generator",
          description: "Create comprehensive brand kits with AI. Generate color palettes, typography, logos, and brand guidelines automatically.",
          icon: icons.brandKit
        },
        {
          name: "Social Media Templates",
          description: "AI-generated social media templates optimized for each platform. Maintain brand consistency across all channels.",
          icon: icons.socialTemplates
        },
        {
          name: "Creative Studio",
          description: "All-in-one creative workspace powered by AI. Design, edit, and optimize visual content for any marketing campaign.",
          icon: icons.creativeStudio
        }
      ]
    }
  ];

  return (
    <div style={{
      fontFamily: 'Poppins, Arial, sans-serif',
      color: '#312727',
      backgroundColor: '#ffffff',
      minHeight: '100vh'
    }}>
      {/* Header */}
      <header style={{
        background: 'linear-gradient(135deg, #a93b43 0%, #312727 100%)',
        color: 'white',
        padding: '4rem 2rem',
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <h1 style={{
            fontSize: '3.5rem',
            fontWeight: '700',
            marginBottom: '1rem',
            textShadow: '2px 2px 4px rgba(0,0,0,0.3)'
          }}>
            ORVISIO TOOL SUITE
          </h1>
          <p style={{
            fontSize: '1.5rem',
            fontWeight: '400',
            marginBottom: '1rem',
            opacity: 0.9
          }}>
            75 Precision-Built AI Tools for Business Growth & Automation
          </p>
          <p style={{
            fontSize: '1.1rem',
            fontWeight: '300',
            maxWidth: '800px',
            margin: '0 auto',
            lineHeight: '1.6',
            opacity: 0.8
          }}>
            Your all-in-one AI powerhouse for marketing, content creation, business intelligence, and automation.
            Precision-built tools for entrepreneurs who demand excellence.
          </p>
        </div>
      </header>

      {/* Stats Section */}
      <section style={{
        backgroundColor: '#f8f8f8',
        padding: '3rem 2rem',
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
            <div>
              <h3 style={{ fontSize: '3rem', fontWeight: '700', color: '#a93b43', margin: 0 }}>75</h3>
              <p style={{ fontSize: '1.1rem', color: '#312727', margin: '0.5rem 0' }}>AI Tools</p>
            </div>
            <div>
              <h3 style={{ fontSize: '3rem', fontWeight: '700', color: '#a93b43', margin: 0 }}>24/7</h3>
              <p style={{ fontSize: '1.1rem', color: '#312727', margin: '0.5rem 0' }}>AI Support</p>
            </div>
            <div>
              <h3 style={{ fontSize: '3rem', fontWeight: '700', color: '#a93b43', margin: 0 }}>100%</h3>
              <p style={{ fontSize: '1.1rem', color: '#312727', margin: '0.5rem 0' }}>AI-Powered</p>
            </div>
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <main style={{ padding: '4rem 2rem', maxWidth: '1400px', margin: '0 auto' }}>
        {toolCategories.map((category) => (
          <section key={category.title} style={{ marginBottom: '4rem' }}>
            <h2 style={{
              fontSize: '2.5rem',
              fontWeight: '600',
              color: '#312727',
              marginBottom: '2rem',
              textAlign: 'center',
              position: 'relative'
            }}>
              {category.title}
              <div style={{
                width: '100px',
                height: '4px',
                backgroundColor: '#a93b43',
                margin: '1rem auto',
                borderRadius: '2px'
              }} />
            </h2>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
              gap: '2rem',
              marginBottom: '3rem'
            }}>
              {category.tools.map((tool) => (
                <div key={tool.name} style={{
                  backgroundColor: 'white',
                  border: '1px solid #e5e5e5',
                  borderRadius: '12px',
                  padding: '2rem',
                  boxShadow: '0 4px 6px rgba(0, 0, 0, 0.05)',
                  transition: 'all 0.3s ease',
                  cursor: 'pointer'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.boxShadow = '0 8px 25px rgba(169, 59, 67, 0.15)';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.borderColor = '#a93b43';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.05)';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.borderColor = '#e5e5e5';
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1rem' }}>
                    <div style={{
                      width: '50px',
                      height: '50px',
                      backgroundColor: '#a93b43',
                      borderRadius: '10px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: '1rem'
                    }}>
                      {tool.icon}
                    </div>
                    <h3 style={{
                      fontSize: '1.4rem',
                      fontWeight: '600',
                      color: '#312727',
                      margin: 0
                    }}>
                      {tool.name}
                    </h3>
                  </div>
                  <p style={{
                    fontSize: '1rem',
                    color: '#666',
                    lineHeight: '1.6',
                    margin: 0
                  }}>
                    {tool.description}
                  </p>
                  <button style={{
                    backgroundColor: '#a93b43',
                    color: 'white',
                    border: 'none',
                    padding: '0.75rem 1.5rem',
                    borderRadius: '6px',
                    fontSize: '0.9rem',
                    fontWeight: '500',
                    marginTop: '1.5rem',
                    cursor: 'pointer',
                    transition: 'background-color 0.3s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#8a2f35';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#a93b43';
                  }}>
                    Try Now
                  </button>
                </div>
              ))}
            </div>
          </section>
        ))}
      </main>

      {/* CTA Section */}
      <section style={{
        background: 'linear-gradient(135deg, #312727 0%, #a93b43 100%)',
        color: 'white',
        padding: '4rem 2rem',
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <h2 style={{
            fontSize: '2.5rem',
            fontWeight: '700',
            marginBottom: '1rem'
          }}>
            Ready to Transform Your Business?
          </h2>
          <p style={{
            fontSize: '1.2rem',
            marginBottom: '2rem',
            opacity: 0.9,
            lineHeight: '1.6'
          }}>
            Join thousands of entrepreneurs and agencies using Orvisio Tool Suite to build profitable, AI-powered businesses.
          </p>
          <button style={{
            backgroundColor: 'white',
            color: '#a93b43',
            border: 'none',
            padding: '1rem 2rem',
            fontSize: '1.1rem',
            fontWeight: '600',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'all 0.3s ease'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#f0f0f0';
            e.currentTarget.style.transform = 'translateY(-2px)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'white';
            e.currentTarget.style.transform = 'translateY(0)';
          }}>
            Get Started Today
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer style={{
        backgroundColor: '#312727',
        color: 'white',
        padding: '3rem 2rem 2rem',
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <h3 style={{ fontSize: '1.5rem', fontWeight: '600', marginBottom: '1rem' }}>
            ORVISIO TOOL SUITE
          </h3>
          <p style={{ opacity: 0.8, marginBottom: '2rem' }}>
            Precision-Built AI Tools. Strategic Excellence. Global Freedom.
          </p>
          <div style={{
            borderTop: '1px solid #555',
            paddingTop: '2rem',
            opacity: 0.6,
            fontSize: '0.9rem'
          }}>
            © 2025 Orvisio Digital Venture. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
