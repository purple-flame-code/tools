
import React from 'react';

const LandingPage = () => {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <h1>Orvisio Tool Suite</h1>
      <p><strong>EN:</strong> Your command center for business tools and AI-driven automation.</p>
      <p><strong>ES:</strong> Tu centro de comando para herramientas empresariales y automatización con inteligencia artificial.</p>
      <ul>
        <li><strong>Copilots AI:</strong> EN: Automate marketing, sales, and content with smart agents. <br /> ES: Automatiza marketing, ventas y contenido con agentes inteligentes.</li>
        <li><strong>Embedded Agents:</strong> EN: Integrate AI assistants into your site or funnels. <br /> ES: Integra asistentes IA en tu web o funnels.</li>
        <li><strong>Video Avatars:</strong> EN: Automated videos using your brand's digital clones. <br /> ES: Videos automatizados con clones digitales de tu marca.</li>
        <li><strong>Dashboards:</strong> EN: Real-time analytics and key performance metrics. <br /> ES: Analíticas en tiempo real y métricas clave.</li>
        <li><strong>Fast Funnels:</strong> EN: No-code sales funnel builder. <br /> ES: Generador de embudos de venta sin código.</li>
        <li><strong>Integrations:</strong> EN: Connect to Shopify, Stripe, Zapier, and more. <br /> ES: Conecta con Shopify, Stripe, Zapier, y más.</li>
      </ul>
      <p style={{ marginTop: '2rem' }}>
        <strong>EN:</strong> Start transforming your digital operation today with Orvisio.<br />
        <strong>ES:</strong> Empieza hoy a transformar tu operación digital con Orvisio.
      </p>
    </div>
  );
};

export default LandingPage;
